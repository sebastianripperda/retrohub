# RetroHub auf GitHub veröffentlichen – Leitfaden

Diese Datei gehört **nicht** ins Repository. Sie enthält alle Schritte und Texte zum Kopieren.

---

## Schritt 1 – Repository auf GitHub anlegen

Auf https://github.com/new:

| Feld | Eintrag |
|---|---|
| Repository name | `retrohub-proxmox` (empfohlen; „retrohub“ ist auf GitHub bereits mehrfach vergeben) |
| Description | siehe unten |
| Sichtbarkeit | Public |
| README, .gitignore, License | **nicht** anhaken – alles ist schon im Paket |

**Description (deutsch):**
```
Deine Retro-Spielesammlung im Heimnetz: Proxmox-LXC-Installer, Emulatoren für 35 Systeme im Browser, Spielstände, Kinderprofile mit Altersfreigabe, Couch-Modus mit Handy-Controllern und Netplay – offline, ohne Cloud. Keine Spiele enthalten.
```

**Description (englisch, falls du international auftreten willst):**
```
Self-hosted retro game library for your home network: Proxmox LXC installer, in-browser emulators for 35 systems, server-side saves, kids' profiles with age ratings, couch mode with phones as controllers, and netplay – offline, no cloud. No games included.
```

---

## Schritt 2 – Paket vorbereiten und hochladen

Auf deinem Rechner (Linux, macOS oder WSL; benötigt `git`):

```bash
tar -xzf retrohub-github.tar.gz
cd retrohub

# einmalig, falls noch nicht geschehen
git config --global user.name  "Dein Name"
git config --global user.email "deine@adresse.de"

# trägt Name und GitHub-Konto ein, legt das Git-Repository mit erstem Commit an
scripts/vorbereiten.sh "Dein Name" dein-github-name retrohub-proxmox

git push -u origin main
```

Das Skript ersetzt die Platzhalter in `LICENSE`, `README.md`, `README.en.md`, `.github/ISSUE_TEMPLATE/config.yml` und `docs/releases/v9.1.1.md` und bricht ab, falls irgendwo noch einer übrig ist.

> Hinweis: Statt deines echten Namens kannst du in `LICENSE` auch ein Pseudonym oder deinen GitHub-Namen verwenden.

---

## Schritt 3 – Einstellungen im Repository

| Ort | Einstellung |
|---|---|
| **About** (Zahnrad rechts oben auf der Startseite) | Description eintragen, Topics hinzufügen (siehe unten), „Releases“ anhaken |
| Settings → General → Social preview | `docs/social-preview.png` hochladen |
| Settings → General → Features | Issues: an · Wiki: aus · Discussions: nach Wunsch |
| Settings → Actions → General → Workflow permissions | **Read and write permissions** (die Release-Action legt Releases an) |
| Settings → Code security | **Private vulnerability reporting** aktivieren, **Dependabot alerts** und **security updates** aktivieren |
| Settings → Branches (optional) | Regel für `main`: Status-Check „Statische Prüfungen und Backend-Test“ muss bestehen |

**Topics:**
```
proxmox lxc homelab self-hosted retro-gaming emulation emulatorjs libretro browser-games nodejs offline-first couch-gaming netplay
```

**Labels**, die die Vorlagen verwenden (Issues → Labels → New label):

| Name | Farbe | Beschreibung |
|---|---|---|
| `fehler` | `#d73a4a` | Etwas funktioniert nicht |
| `wunsch` | `#a2eeef` | Idee oder Verbesserung |
| `abhängigkeiten` | `#0366d6` | Updates durch Dependabot |

Oder mit der GitHub-Kommandozeile (`gh`):
```bash
gh label create fehler --color d73a4a --description "Etwas funktioniert nicht"
gh label create wunsch --color a2eeef --description "Idee oder Verbesserung"
gh label create "abhängigkeiten" --color 0366d6 --description "Updates durch Dependabot"
```

Danach unter **Actions** prüfen, dass „Prüfungen“ grün durchgelaufen ist.

---

## Schritt 4 – Erstes Release

```bash
git tag -a v9.1.1 -m "RetroHub 9.1.1"
git push origin v9.1.1
```

Die Action „Release“ prüft alles erneut, baut `RetroHub-v9.1.1-AutoInstaller.tar.gz` mit `.sha256` und veröffentlicht das Release mit dem Text aus `docs/releases/v9.1.1.md`. Titel: **RetroHub v9.1.1**.

Für spätere Versionen: `VERSION`, `package.json`, `server/package.json`, `RH_VERSION` in `install.sh` und `CHANGELOG.md` anpassen (`npm run check` prüft die Übereinstimmung), dann neuen Tag pushen. Ohne eigene Datei in `docs/releases/` wird der Abschnitt aus `CHANGELOG.md` verwendet.

---

## Schritt 5 – Bekanntmachen (optional)

**Kurztext für Foren (z. B. r/Proxmox, r/selfhosted, Proxmox-Forum, Homelab-Communities):**

> **RetroHub – eigene Retro-Spielesammlung als Proxmox-Container**
> Ich habe ein Open-Source-Projekt veröffentlicht, das eigene Spieldateien im Heimnetz im Browser spielbar macht: Ein Installer legt einen unprivilegierten LXC an, lädt Emulatoren für 35 Systeme (EmulatorJS) und richtet alles ein. Dazu gibt es Spielstände auf dem Server, Kinderprofile mit Altersfreigabe, einen Couch-Modus mit Handys als Controller und experimentelles Netplay. Läuft offline, ohne Cloud. Es sind keine Spiele enthalten – nur eigene Dateien.
> Ich freue mich über Rückmeldungen, besonders von echten Proxmox-Hosts und Mobilgeräten: https://github.com/DEINNAME/retrohub-proxmox

**English:**

> **RetroHub – a self-hosted retro game library as a Proxmox container**
> Open source project that makes your own game files playable in the browser on your home network: an installer creates an unprivileged LXC, downloads emulators for 35 systems (EmulatorJS) and sets everything up. Server-side save states, kids' profiles with age ratings, couch mode with phones as controllers, experimental netplay. Offline, no cloud, no games included. Feedback welcome, especially from real Proxmox hosts and mobile devices.

---

## Checkliste vor dem Klick auf „Public“

- [ ] `scripts/vorbereiten.sh` ausgeführt – keine Platzhalter mehr
- [ ] Keine eigenen Spieldateien, BIOS oder Zugangsdaten im Ordner (das Paket enthält keine; nur prüfen, falls du etwas ergänzt hast)
- [ ] Erster Lauf der Action „Prüfungen“ ist grün
- [ ] Social Preview hochgeladen, Topics gesetzt
- [ ] Private vulnerability reporting aktiv
- [ ] Release v9.1.1 erstellt und Archiv lässt sich herunterladen

## Rechtlicher Hinweis

RetroHub steht unter MIT. EmulatorJS (GPL-3.0) wird nicht mitgeliefert, sondern bei der Installation geladen. Die drei Netplay-Korrekturen in `games/sources.json` enthalten kurze Auszüge aus EmulatorJS; sie sind in `THIRD_PARTY_NOTICES.md` als GPL-3.0 gekennzeichnet. Das ist keine Rechtsberatung – wer ganz sichergehen möchte, stellt das gesamte Projekt unter GPL-3.0.
